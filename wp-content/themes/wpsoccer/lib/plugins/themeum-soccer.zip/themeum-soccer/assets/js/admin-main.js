jQuery(document).ready(function(){'use strict';

/*
jQuery('#reasult_group').hide();
jQuery('#classic_group').show();

jQuery('#select_type').on( 'change' ,function() {
        if( jQuery('#select_type option:selected').val() == "value1" ){
        	 jQuery('#reasult_group').hide();
        	 jQuery('#classic_group').show();
        }else{
        	jQuery('#reasult_group').show();
        	jQuery('#classic_group').hide();
        }

        // var val1 = jQuery('#pick option:selected').val();  value1
    }
);
*/

});